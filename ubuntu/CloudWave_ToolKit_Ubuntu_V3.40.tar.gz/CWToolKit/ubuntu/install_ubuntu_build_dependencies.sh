#!/usr/bin/env bash
#
###############################################################################
# Copyright 2014 INTEL RESEARCH AND INNOVATION IRELAND LIMITED
# 
# Redistribution. 
# --------------
# Redistribution and use in binary form, without modification, are permitted 
# provided that the following conditions are met:
#    * Redistributions must reproduce the above copyright notice and the following
#      disclaimer in the documentation and/or other materials provided with the
#      distribution.
#     
#    * Neither the name of Intel Corporation nor the names of its suppliers may
#      be used to endorse or promote products derived from this software without
#      specific prior written permission.
#      
#    * No reverse engineering, decompilation, or disassembly of this software is 
#      permitted.
#      
# Limited patent license.
# -----------------------
# Intel Corporation grants a world-wide, royalty-free, non-exclusive license
# under patents it now or hereafter owns or controls to make, have made, use,
# import, offer to sell and sell ("Utilize") this software, but solely to the
# extent that any such patent is necessary to Utilize the software alone.
# The patent license shall not apply to any combinations which include this 
# software. No hardware per se is licensed hereunder.
# 
# DISCLAIMER.
# -----------
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
###############################################################################
#
# Small independent file to set up the required dependencies
#
# Assumes a simple Ubuntu 14 installation
# tested on 10.04 Server LTS with Openssh installed
#
###############################################################################
# Locations for everything
TMP=/tmp

MYHOME=$(pwd)

# clear any outstanding (and in case sudo was used !)
sudo rm -rf $TMP/cloudwave
# Make a staging directory
mkdir -p $TMP/cloudwave

###############################################################################
echo " "
echo " "
echo " $ ssh root@localhost"
echo " # visudo"
echo " add a line just under 'root  ALL = (ALL ) ALL"
echo "   with"
echo " your_user_name   ALL (ALL) ALL"
echo " "

###############################################################################

function print {
  echo -e '\e[33m\e[44m' $1 '\e[0m'
}

###############################################################################

print 'Ubuntu : Configuring Build Environment & cloudwave.so dependencies'


###############################################################################
#
# tools required
#
print 'Installing Development Tools'
sudo apt-get update -y
sudo apt-get -qy upgrade
sudo apt-get -qy install build-essential
sudo apt-get -qy install cmake
sudo apt-get -qy install swig
sudo apt-get -qy install make
sudo apt-get -qy install ruby
sudo apt-get -qy install help2man
sudo apt-get -qy install doxygen
sudo apt-get -qy install libboost-all-dev
sudo apt-get -qy install libuuid-perl libuuid1
sudo apt-get -qy install uuid-dev uuid-runtime
sudo apt-get -qy install python-qpid
sudo apt-get -qy install libcurl4-openssl-dev
sudo apt-get -qy install coreutils
sudo apt-get -qy install realpath
sudo apt-get -qy install unzip
#
sudo apt-get -qy install openjdk-7-jre
sudo apt-get -qy install openjdk-7-jre-lib
sudo apt-get -qy install openjdk-7-jdk
sudo apt-get -qy install libssl-dev
#
#
###############################################################################
## ------ qpid ------
## .. Version 2 support !
##
##
## http://svn.apache.org/repos/asf/qpid/trunk/qpid/cpp/INSTALL
##
## * boost      <http://www.boost.org>                    (1.41) (*)
## * libuuid    <http://kernel.org/~kzak/util-linux/>     (2.19)
## * pkgconfig  <http://pkgconfig.freedesktop.org/wiki/>  (0.21)
##
##
## VERSION 0.28
#print 'Install Qpid V0.28'
##
#pushd $TMP/cloudwave
#wget http://archive.apache.org/dist/qpid/0.28/qpid-0.28.tar.gz
#tar -xvzf qpid-0.28.tar.gz
#cd qpid-0.28
#cd cpp
#mkdir bld
#cd bld
##cmake ..
##cmake -DCMAKE_CXX_FLAGS="-std=c++11 -Wno-error=deprecated-declarations" ..
#cmake -DCMAKE_CXX_FLAGS="-std=c++0x -Wno-error=deprecated-declarations" ..
#make all
##
#sudo make install
## tools
#cd ../../tools
#sudo ./setup.py install
##
##
## VERSION 0.30 (Beta)
##print 'Install Qpid V0.30'
##
##wget -P $TMP http://mirror.ox.ac.uk/sites/rsync.apache.org/qpid/0.30/qpid-cpp-0.30.tar.gz
##
##pushd $TMP
##tar -xvzf qpid-cpp-0.30.tar.gz
##cd qpid-cpp-0.30
##mkdir bld
##cd bld
###cmake ..
###cmake -DCMAKE_CXX_FLAGS="-std=c++11 -Wno-error=deprecated-declarations" ..
##cmake -DCMAKE_CXX_FLAGS="-std=c++0x -Wno-error=deprecated-declarations" ..
##make all
###
##make install
##
##
#popd
##
#
# VERSION 0.34
print 'Install Qpid V0.34'
#
pushd $TMP/cloudwave
# wget http://www.apache.org/dist/qpid/cpp/0.34/qpid-cpp-0.34.tar.gz
#curl -# -o qpid-cpp-0.34.tar.gz http://www.apache.org/dist/qpid/cpp/0.34/qpid-cpp-0.34.tar.gz
wget http://www.apache.org/dist/qpid/cpp/0.34/qpid-cpp-0.34.tar.gz
tar -xvzf qpid-cpp-0.34.tar.gz
cd qpid-cpp-0.34
mkdir build
cd build
cmake ..
###cmake -DCMAKE_CXX_FLAGS="-std=c++11 -Wno-error=deprecated-declarations" ..
##cmake -DCMAKE_CXX_FLAGS="-std=c++0x -Wno-error=deprecated-declarations" ..
make all
sudo make install
popd
#
################################################################################
#
# Install rabbit
#
pushd $TMP/cloudwave
sudo apt-get -qy install rabbitmq-server
popd
#
#
################################################################################
#
# Install rabbitmq development
#
print 'Installing rabbitmq development'
#
pushd $TMP/cloudwave
wget https://github.com/alanxz/rabbitmq-c/archive/master.zip
unzip master.zip
cd rabbitmq-c-master
mkdir build
cd build
cmake ..
# make
cmake --build .
sudo make install
popd
#
################################################################################
#
print 'Installing Proton'
#
pushd $TMP/cloudwave
wget -q http://mirror.catn.com/pub/apache/qpid/proton/0.9.1/qpid-proton-0.9.1.tar.gz
tar xzf qpid-proton-0.9.1.tar.gz
cd qpid-proton-0.9.1-rc1
mkdir build
cd build
cmake .. -DCMAKE_INSTALL_PREFIX=/usr -DSYSINSTALL_BINDINGS=ON
make clean
make all docs
sudo make install
popd
#
################################################################################
#
#
print 'Installing jansson'
#
pushd $TMP/cloudwave
wget http://www.digip.org/jansson/releases/jansson-2.7.tar.gz
tar -xvzf jansson-2.7.tar.gz
cd jansson-2.7/
./configure
make
sudo make install
popd

################################################################################
## We need the Python qpidd config files .. install these
## version 2 support
##
#sudo yum install python-qpid
##
################################################################################

# update the ldconfig, write out a tmp file
#
print 'Setup the linker cache'
# --------------
# Update the linker cache
LIBFILE="usrlocal.conf"
/bin/cat <<EOM >$LIBFILE
#
# Make libraries available
# # required for rabbit-mq
/usr/local/lib/x86_64-linux-gnu
#
EOM
#
# Copy this to the ldconf location
sudo mv $LIBFILE /etc/ld.so.conf.d/
#
sudo ldconfig
#
###############################################################################

# Get back home, and tidy up

print 'Tidy Up'
sudo rm -rf $TMP/cloudwave
#
#
cd $MYHOME

print 'finished'

