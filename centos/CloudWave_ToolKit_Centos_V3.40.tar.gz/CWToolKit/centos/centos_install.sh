#!/usr/bin/env bash
#
###############################################################################
# Copyright 2014 INTEL RESEARCH AND INNOVATION IRELAND LIMITED
# 
# Redistribution. 
# --------------
# Redistribution and use in binary form, without modification, are permitted 
# provided that the following conditions are met:
#    * Redistributions must reproduce the above copyright notice and the following
#      disclaimer in the documentation and/or other materials provided with the
#      distribution.
#     
#    * Neither the name of Intel Corporation nor the names of its suppliers may
#      be used to endorse or promote products derived from this software without
#      specific prior written permission.
#      
#    * No reverse engineering, decompilation, or disassembly of this software is 
#      permitted.
#      
# Limited patent license.
# -----------------------
# Intel Corporation grants a world-wide, royalty-free, non-exclusive license
# under patents it now or hereafter owns or controls to make, have made, use,
# import, offer to sell and sell ("Utilize") this software, but solely to the
# extent that any such patent is necessary to Utilize the software alone.
# The patent license shall not apply to any combinations which include this 
# software. No hardware per se is licensed hereunder.
# 
# DISCLAIMER.
# -----------
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
# ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
# ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
###############################################################################
#
# Small independent file to set up the required dependencies
#
# Assumes a simple Centos 7 installation
#
###############################################################################

function print {
  echo -e '\e[33m\e[44m' $1 '\e[0m'
}

###############################################################################
#
print 'Install the include files'
sudo rm -rf /usr/local/include/cloudwave
sudo mkdir -p /usr/local/include/cloudwave
sudo install inc/*.h /usr/local/include/cloudwave
#
print 'Install the SO library'
sudo rm -f /usr/local/lib/libcloudwave.*
sudo install lib/libcloudwave.so /usr/local/lib/libcloudwave.so.1
sudo ln -s /usr/local/lib/libcloudwave.so.1 /usr/local/lib/libcloudwave.so
#
print 'Install the system files'
sudo install system/* /usr/local/bin
#
# Optional
print 'Install the utility files'
sudo install util/* /usr/local/bin
#
#
################################################################################
#
# update the ldconfig, write out a tmp file
#
print 'Setup the linker cache'
# --------------
# Update the linker cache
LIBFILE="usrlocal.conf"
/bin/cat <<EOM >$LIBFILE
#
# Make libraries available
#
/usr/local/lib
/usr/local/lib/x86_64-linux-gnu
#
EOM
#
# Copy this to the ldconf location
sudo mv $LIBFILE /etc/ld.so.conf.d/
# and update the database
sudo ldconfig
#



