#!/bin/bash
#
#
# Put the so into thte java path
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/lib
#
# Permit the user to see some debugging info
export CLOUDWAVE_TRACE_ON="ON"
#
#
#exit
